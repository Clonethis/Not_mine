﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NIA
{
    public partial class Main : Form
    {
        HttpClient client;
        String loginUrl;
        String statusUrl;
        String tokenUrl;

        public Main()
        {
            InitializeComponent();

            String baseUrl = "https://testnia.sukl.cz/nia/ext/v1/login/";
            String statusBaseUrl = "https://testnia.sukl.cz/nia/ext/v1/stav/";
            String tokenBaseUrl = "https://testnia.sukl.cz/nia/ext/v1/token/";

            baseUrlInput.Text = baseUrl;
            statusInput.Text = statusBaseUrl;
            tokenInput.Text = tokenBaseUrl;
            param1Input.Text = System.Guid.NewGuid().ToString();
        }

        private void startButton_Click(object sender, EventArgs e)
        {
            if (param1Input.Text == "")
            {
                terminalInput.Text += "Není vyplněno UUID volání." + Environment.NewLine;
                return;
            }

            if (param2Input.Text == "")
            {
                terminalInput.Text += "Není vyplněn login klienta." + Environment.NewLine;
                return;
            }

            // znemozni editaci parametru 
            enableControls(false);

            // slozeni url pro login volani NIA 
            loginUrl = baseUrlInput.Text + param1Input.Text + "/osoba/" + param2Input.Text + "?redirect=false";

            // slozeni url pro ziskani stavu NIA 
            statusUrl = statusInput.Text + param1Input.Text;

            // slozeni url pro ziskani tokenu NIA 
            tokenUrl = tokenInput.Text + param1Input.Text;

            String res;

            // init http klienta, certifikat, heslo
            client = createCertContext();
            if (client == null)
                return;

            terminalInput.Text += "Přihlašuji..." + Environment.NewLine;

            // https volani login url, response se pouzije pro otevreni v prohlizeci
            using (HttpResponseMessage response = client.GetAsync(loginUrl).Result)
            {
                using (HttpContent content = response.Content)
                {
                    res = content.ReadAsStringAsync().Result;

                    if (Uri.IsWellFormedUriString(res, UriKind.Absolute))
                    {
                        // otevre defaultni prohlizec s url ziskanou z odpovedi
                        Process.Start(new ProcessStartInfo { FileName = res, UseShellExecute = true });
                    }
                    else
                    {
                        APIResponse dataContractDetail = jsonParse(res);

                        if (dataContractDetail.popisChyby != null)
                        {
                            logResponse("LOGIN", (int)response.StatusCode, dataContractDetail.popisChyby);
                            enableControls(true);
                            return;
                        } 
                    }
                }
            }

            // zacne v pravidelnem internavalu provolavat status url
            timer1.Enabled = true;
        }

        private void stopButton_Click(object sender, EventArgs e)
        {
            enableControls(true);
            timer1.Enabled = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            // v danem casovem intervalu provolava stav url a vypise json z odpovedi
            using (HttpResponseMessage response = client.GetAsync(statusUrl).Result)
            {
                using (HttpContent content = response.Content)
                {
                    var res = content.ReadAsStringAsync().Result;

                    APIResponse dataContractDetail = jsonParse(res);

                    if (dataContractDetail.popisChyby != null)
                    {
                        logResponse("STAV", (int)response.StatusCode, dataContractDetail.popisChyby);
                    }
                    else if (dataContractDetail.stavID != null)
                    {
                        logResponse("STAV", (int)response.StatusCode, "stavID: " + dataContractDetail.stavID);

                        if (dataContractDetail.stavID == (int)3)
                        {
                            // pokud se stavID == 3, provola token url
                            getToken();
                        }
                    }
                }
            }
        }

        private void getToken()
        {
            // vraceni tokenu a dalsich informaci na zaklade uspesneho prihlaseni pres NIA
            using (HttpResponseMessage response = client.GetAsync(tokenUrl).Result)
            {
                using (HttpContent content = response.Content)
                {
                    var res = content.ReadAsStringAsync().Result;

                    APIResponse dataContractDetail = jsonParse(res);

                    if (dataContractDetail.popisChyby != null)
                    {
                        logResponse("TOKEN", (int)response.StatusCode, dataContractDetail.popisChyby);
                    }
                    else if (dataContractDetail.token != null)
                    {
                        logResponse("TOKEN", (int)response.StatusCode, res);
                    }
                    enableControls(true);
                    timer1.Enabled = false;
                }
            }
        }

        private void certButton_Click(object sender, EventArgs e)
        {
            DialogResult result = openFileDialog1.ShowDialog(); // Show the dialog.
            if (result == DialogResult.OK) // Test result.
            {
                string file = openFileDialog1.FileName;
                certInput.Text = file;
            }
        }

        private HttpClient createCertContext()
        {
            var handler = new HttpClientHandler();
            handler.ClientCertificateOptions = ClientCertificateOption.Manual;
            handler.SslProtocols = SslProtocols.Tls12;
            try
            {
                handler.ClientCertificates.Add(new X509Certificate2(certInput.Text, hesloInput.Text));
            }
            catch (Exception exception)
            {
                logResponse("CERTIFIKAT", 0, exception.Message);
                enableControls(true);
                return null;
            }
            return new HttpClient(handler);
        }

        private APIResponse jsonParse(String res)
        {
            DataContractJsonSerializer jsonSerializer = new DataContractJsonSerializer(typeof(APIResponse));
            MemoryStream stream = new MemoryStream(Encoding.UTF8.GetBytes(res));
            stream.Position = 0;
            return (APIResponse)jsonSerializer.ReadObject(stream);
        }

        private void logResponse(String type, int resCode, String message)
        {
            terminalInput.AppendText(DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") + " (" + type + ") - " + resCode + " - " + message + Environment.NewLine);
        }
        private void enableControls(bool enable)
        {
            param1Input.Enabled = enable;
            param2Input.Enabled = enable;
            startButton.Enabled = enable;
            stopButton.Enabled = !enable;
            certInput.Enabled = enable;
            hesloInput.Enabled = enable;
            certButton.Enabled = enable;
        }
    }
}

[DataContract]
public class APIResponse
{
    [DataMember]
    public string popisChyby
    {
        get;
        set;
    }

    [DataMember]
    public int stavID
    {
        get;
        set;
    }

    [DataMember]
    public String token
    {
        get;
        set;
    }
}
