﻿
namespace NIA
{
    partial class Main
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.startButton = new System.Windows.Forms.Button();
            this.baseUrlInput = new System.Windows.Forms.TextBox();
            this.titleLabel = new System.Windows.Forms.Label();
            this.baseUrlLabel = new System.Windows.Forms.Label();
            this.param1Label = new System.Windows.Forms.Label();
            this.param1Input = new System.Windows.Forms.TextBox();
            this.param2Label = new System.Windows.Forms.Label();
            this.param2Input = new System.Windows.Forms.TextBox();
            this.stopButton = new System.Windows.Forms.Button();
            this.statusLabel = new System.Windows.Forms.Label();
            this.statusInput = new System.Windows.Forms.TextBox();
            this.terminalInput = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.certLabel = new System.Windows.Forms.Label();
            this.certInput = new System.Windows.Forms.TextBox();
            this.hesloLabel = new System.Windows.Forms.Label();
            this.hesloInput = new System.Windows.Forms.TextBox();
            this.certButton = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.tokenLabel = new System.Windows.Forms.Label();
            this.tokenInput = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // startButton
            // 
            this.startButton.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.startButton.Location = new System.Drawing.Point(79, 317);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(107, 41);
            this.startButton.TabIndex = 0;
            this.startButton.Text = "START";
            this.startButton.UseVisualStyleBackColor = true;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // baseUrlInput
            // 
            this.baseUrlInput.Enabled = false;
            this.baseUrlInput.Location = new System.Drawing.Point(226, 138);
            this.baseUrlInput.Name = "baseUrlInput";
            this.baseUrlInput.Size = new System.Drawing.Size(551, 23);
            this.baseUrlInput.TabIndex = 1;
            // 
            // titleLabel
            // 
            this.titleLabel.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.titleLabel.Location = new System.Drawing.Point(21, 9);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(450, 39);
            this.titleLabel.TabIndex = 2;
            this.titleLabel.Text = "NIA POC - těžký klient .NET - ukázka";
            // 
            // baseUrlLabel
            // 
            this.baseUrlLabel.AutoSize = true;
            this.baseUrlLabel.Location = new System.Drawing.Point(24, 141);
            this.baseUrlLabel.Name = "baseUrlLabel";
            this.baseUrlLabel.Size = new System.Drawing.Size(72, 15);
            this.baseUrlLabel.TabIndex = 3;
            this.baseUrlLabel.Text = "API url login";
            // 
            // param1Label
            // 
            this.param1Label.AutoSize = true;
            this.param1Label.Location = new System.Drawing.Point(24, 176);
            this.param1Label.Name = "param1Label";
            this.param1Label.Size = new System.Drawing.Size(69, 15);
            this.param1Label.TabIndex = 5;
            this.param1Label.Text = "UUID volání";
            // 
            // param1Input
            // 
            this.param1Input.Location = new System.Drawing.Point(226, 173);
            this.param1Input.Name = "param1Input";
            this.param1Input.Size = new System.Drawing.Size(551, 23);
            this.param1Input.TabIndex = 4;
            // 
            // param2Label
            // 
            this.param2Label.AutoSize = true;
            this.param2Label.Location = new System.Drawing.Point(24, 211);
            this.param2Label.Name = "param2Label";
            this.param2Label.Size = new System.Drawing.Size(75, 15);
            this.param2Label.TabIndex = 7;
            this.param2Label.Text = "Login klienta";
            // 
            // param2Input
            // 
            this.param2Input.Location = new System.Drawing.Point(226, 208);
            this.param2Input.Name = "param2Input";
            this.param2Input.Size = new System.Drawing.Size(551, 23);
            this.param2Input.TabIndex = 6;
            // 
            // stopButton
            // 
            this.stopButton.Location = new System.Drawing.Point(597, 317);
            this.stopButton.Name = "stopButton";
            this.stopButton.Size = new System.Drawing.Size(125, 41);
            this.stopButton.TabIndex = 8;
            this.stopButton.Text = "STOP";
            this.stopButton.UseVisualStyleBackColor = true;
            this.stopButton.Click += new System.EventHandler(this.stopButton_Click);
            // 
            // statusLabel
            // 
            this.statusLabel.AutoSize = true;
            this.statusLabel.Location = new System.Drawing.Point(24, 246);
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(66, 15);
            this.statusLabel.TabIndex = 10;
            this.statusLabel.Text = "API url stav";
            // 
            // statusInput
            // 
            this.statusInput.Enabled = false;
            this.statusInput.Location = new System.Drawing.Point(226, 243);
            this.statusInput.Name = "statusInput";
            this.statusInput.Size = new System.Drawing.Size(551, 23);
            this.statusInput.TabIndex = 9;
            // 
            // terminalInput
            // 
            this.terminalInput.Location = new System.Drawing.Point(25, 364);
            this.terminalInput.Multiline = true;
            this.terminalInput.Name = "terminalInput";
            this.terminalInput.ReadOnly = true;
            this.terminalInput.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.terminalInput.Size = new System.Drawing.Size(752, 224);
            this.terminalInput.TabIndex = 11;
            // 
            // timer1
            // 
            this.timer1.Interval = 5000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // certLabel
            // 
            this.certLabel.AutoSize = true;
            this.certLabel.Location = new System.Drawing.Point(24, 67);
            this.certLabel.Name = "certLabel";
            this.certLabel.Size = new System.Drawing.Size(122, 15);
            this.certLabel.TabIndex = 13;
            this.certLabel.Text = "Autentizační certifikát";
            // 
            // certInput
            // 
            this.certInput.Location = new System.Drawing.Point(226, 64);
            this.certInput.Name = "certInput";
            this.certInput.Size = new System.Drawing.Size(410, 23);
            this.certInput.TabIndex = 12;
            // 
            // hesloLabel
            // 
            this.hesloLabel.AutoSize = true;
            this.hesloLabel.Location = new System.Drawing.Point(24, 104);
            this.hesloLabel.Name = "hesloLabel";
            this.hesloLabel.Size = new System.Drawing.Size(121, 15);
            this.hesloLabel.TabIndex = 15;
            this.hesloLabel.Text = "Heslo privátního klíče";
            // 
            // hesloInput
            // 
            this.hesloInput.Location = new System.Drawing.Point(226, 101);
            this.hesloInput.Name = "hesloInput";
            this.hesloInput.PasswordChar = '*';
            this.hesloInput.Size = new System.Drawing.Size(551, 23);
            this.hesloInput.TabIndex = 14;
            // 
            // certButton
            // 
            this.certButton.Location = new System.Drawing.Point(655, 64);
            this.certButton.Name = "certButton";
            this.certButton.Size = new System.Drawing.Size(121, 23);
            this.certButton.TabIndex = 16;
            this.certButton.Text = "Vyhledat";
            this.certButton.UseVisualStyleBackColor = true;
            this.certButton.Click += new System.EventHandler(this.certButton_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // tokenLabel
            // 
            this.tokenLabel.AutoSize = true;
            this.tokenLabel.Location = new System.Drawing.Point(24, 282);
            this.tokenLabel.Name = "tokenLabel";
            this.tokenLabel.Size = new System.Drawing.Size(75, 15);
            this.tokenLabel.TabIndex = 18;
            this.tokenLabel.Text = "API url token";
            // 
            // tokenInput
            // 
            this.tokenInput.Enabled = false;
            this.tokenInput.Location = new System.Drawing.Point(226, 279);
            this.tokenInput.Name = "tokenInput";
            this.tokenInput.Size = new System.Drawing.Size(551, 23);
            this.tokenInput.TabIndex = 17;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 600);
            this.Controls.Add(this.tokenLabel);
            this.Controls.Add(this.tokenInput);
            this.Controls.Add(this.certButton);
            this.Controls.Add(this.hesloLabel);
            this.Controls.Add(this.hesloInput);
            this.Controls.Add(this.certLabel);
            this.Controls.Add(this.certInput);
            this.Controls.Add(this.terminalInput);
            this.Controls.Add(this.statusLabel);
            this.Controls.Add(this.statusInput);
            this.Controls.Add(this.stopButton);
            this.Controls.Add(this.param2Label);
            this.Controls.Add(this.param2Input);
            this.Controls.Add(this.param1Label);
            this.Controls.Add(this.param1Input);
            this.Controls.Add(this.baseUrlLabel);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.baseUrlInput);
            this.Controls.Add(this.startButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Main";
            this.Text = "NIA POC";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.TextBox baseUrlInput;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Label baseUrlLabel;
        private System.Windows.Forms.Label param1Label;
        private System.Windows.Forms.TextBox param1Input;
        private System.Windows.Forms.Label param2Label;
        private System.Windows.Forms.TextBox param2Input;
        private System.Windows.Forms.Button stopButton;
        private System.Windows.Forms.Label statusLabel;
        private System.Windows.Forms.TextBox statusInput;
        private System.Windows.Forms.TextBox terminalInput;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label certLabel;
        private System.Windows.Forms.TextBox certInput;
        private System.Windows.Forms.Label hesloLabel;
        private System.Windows.Forms.TextBox hesloInput;
        private System.Windows.Forms.Button certButton;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label tokenLabel;
        private System.Windows.Forms.TextBox tokenInput;
    }
}

