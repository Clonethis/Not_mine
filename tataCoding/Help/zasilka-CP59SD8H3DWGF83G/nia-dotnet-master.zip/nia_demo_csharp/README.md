PUBLISH .NET 5
--------------

LINUX  
dotnet publish -r linux-x64 /p:PublishSingleFile=true

WINDOWS  
dotnet publish -r win-x64 /p:PublishSingleFile=true

WINDOWS with Extraction  
dotnet publish -r win-x64 /p:PublishSingleFile=true /p:IncludeNativeLibrariesForSelfExtract=true /p:PublishTrimmed=true