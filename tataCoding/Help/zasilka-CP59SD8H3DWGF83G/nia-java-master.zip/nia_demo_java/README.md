Pokud není nastaven trvale, nastavit JAVA_HOME env var.  
např.: export JAVA_HOME="/home/jan/.jdks/openjdk-15.0.2"

DEVELOPMENT spuštění:  
./gradlew run

BUILD:  (build.gradle odkomentovat v "dependencies" a "jlink" pozadovanou platformu)
./gradlew clean
./gradlew jlink

Výsledný program je v "cd /image/bin"  
Spuštění WIN: nia.bat
Spuštění LINUX: ./nia
