module niapoc {
    requires javafx.controls;
    requires javafx.fxml;
    requires jdk.crypto.ec;
    requires com.google.gson;

    opens niapoc to javafx.fxml, com.google.gson;

    exports niapoc;
}