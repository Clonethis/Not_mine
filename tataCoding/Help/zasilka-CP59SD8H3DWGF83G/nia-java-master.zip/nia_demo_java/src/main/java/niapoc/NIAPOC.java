package niapoc;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class NIAPOC extends Application {
    private static Stage primaryStage;

    @Override
    public void start(Stage primaryStage) throws Exception {
        setPrimaryStage(primaryStage);
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/sample.fxml"));
        Parent root = loader.load();
        Controller fXMLDocumentController = loader.getController();
        fXMLDocumentController.setGetHostController(getHostServices());
        primaryStage.setTitle("NIA POC");
        primaryStage.setScene(new Scene(root, 800, 600));
        primaryStage.show();
    }

    private void setPrimaryStage(Stage stage) {
        NIAPOC.primaryStage = stage;
    }

    static public Stage getPrimaryStage() {
        return NIAPOC.primaryStage;
    }

    public static void main(String[] args) {
        launch();
    }
}