package niapoc;

import com.google.gson.Gson;
import javafx.application.HostServices;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import java.io.*;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URISyntaxException;
import java.net.URL;
import java.security.*;
import java.security.cert.CertificateException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

public class Controller {
    @FXML
    private TextField certPath;
    @FXML
    private TextField password;
    @FXML
    private TextField niaUrlBase;
    @FXML
    private TextField niaUrlParam1;
    @FXML
    private TextField niaUrlParam2;
    @FXML
    private TextField niaStavUrl;
    @FXML
    private TextField niaTokenUrl;
    @FXML
    private Button startButton;
    @FXML
    private Button stopButton;
    @FXML
    private Button certButton;
    @FXML
    private TextFlow txa;
    @FXML
    private ScrollPane scrollPane;

    HostServices hostServices;
    Boolean isRunning = false;
    KeyStore keyStore = null;
    SSLSocketFactory sslSocketFactory = null;

    @FXML
    private void initialize() {
        niaUrlParam1.setText(String.valueOf(UUID.randomUUID()));
        niaUrlBase.setText("https://testnia.sukl.cz/nia/ext/v1/login/");
        niaStavUrl.setText("https://testnia.sukl.cz/nia/ext/v1/stav/");
        niaTokenUrl.setText("https://testnia.sukl.cz/nia/ext/v1/token/");
    }

    public void setGetHostController(HostServices hostServices) {
        this.hostServices = hostServices;
    }

    public void onLoadCertButtonClicked() {
        Stage s = NIAPOC.getPrimaryStage();

        // otevre file dialog pro zvoleni souboru certifikatu
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Resource File");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Cert files", "*.pfx"),
                new FileChooser.ExtensionFilter("All Files", "*.*"));
        File selectedFile = fileChooser.showOpenDialog(s);

        if (selectedFile != null) {
            certPath.setText(selectedFile.getPath());
        }
    }

    public void onStartButtonClicked() throws InterruptedException {
        // disable prvky formulare pro editaci
        disableForm(true);

        // vytvoreni SSL context pro connection s certifikatem
        sslSocketFactory = createSSLContext(certPath.getText(), password.getText());
        if (sslSocketFactory == null)
            return;

        // log do terminalu zacatek provolani API
        logToTerminal("Připojuji se..." + System.getProperty("line.separator"), "");

        // provola login API, ziska url z API a url otevre v defaultnim prohlizeci uzivatele
        new Thread(loginCallTask).start();

        // kazdych 5 sekund provolava API status url a zobrazi navraceny JSON do terminalu
        new Thread(stavCallTask).start();
    }

    Runnable loginCallTask = new Runnable() {
        @Override
        public void run() {
            HttpsURLConnection connection = null;

            try {
                // vytvoreni https spojeni
                URL apiCallUrl = new URL(niaUrlBase.getText() + niaUrlParam1.getText() + "/osoba/" + niaUrlParam2.getText() + "?redirect=false");

                connection = (HttpsURLConnection) apiCallUrl.openConnection();
                connection.setRequestMethod("GET");
                connection.setRequestProperty("User-Agent", "Chrome");
                connection.setReadTimeout(5000);

                connection.setSSLSocketFactory(sslSocketFactory);

                // po provolani ziskam odpoved z API
                int responseCode = connection.getResponseCode();

                // pokud se vrati chybovy kod, vyhodi se chyba do logu
                if (responseCode > 299) {
                    logApiResponse("LOGIN", connection.getErrorStream(), responseCode);
                    disableForm(false);
                } else {
                    // pokud 200 a naparsuji url, tak otevru v prohlizeci
                    String res = logApiResponse("LOGIN", connection.getInputStream(), responseCode);
                    try {
                        URL u = new URL(res);
                        u.toURI();
                        hostServices.showDocument(res);
                    } catch ( MalformedURLException e) {
                        // kdyz nenaparsuji url ukoncim flow
                        disableForm(false);
                    }
                }
            } catch (java.net.SocketTimeoutException e) {
                Platform.runLater(() -> {
                    logToTerminal("Timed out!" + System.getProperty("line.separator"), "");
                    disableForm(false);
                });
            } catch (ProtocolException | URISyntaxException e) {
                Platform.runLater(() -> {
                    e.printStackTrace();
                    disableForm(false);
                });
            } catch (IOException e) {
                Platform.runLater(() -> {
                    e.printStackTrace();
                    disableForm(false);
                });
            }
        }
    };


    Runnable stavCallTask = new Runnable() {
        @Override
        public void run() {
            HttpsURLConnection connection = null;

            try {
                Thread.sleep(5000);
                if (!isRunning) {
                    return;
                }

                // vytvoreni https spojeni
                URL apiCallUrl = new URL(niaStavUrl.getText() + niaUrlParam1.getText());
                connection = (HttpsURLConnection) apiCallUrl.openConnection();
                connection.setRequestMethod("GET");
                connection.setRequestProperty("User-Agent", "Chrome");
                connection.setReadTimeout(5000);
                connection.setSSLSocketFactory(sslSocketFactory);

                // po provolani ziskam odpoved z API
                int statusResponseCode = connection.getResponseCode();

                // pokud se vrati chybovy kod, zaloguji error
                if (statusResponseCode > 299) {
                    logApiResponse("STAV", connection.getErrorStream(), statusResponseCode);
                } else {
                    // jinak zaloguji odpoved
                    String res = logApiResponse("STAV", connection.getInputStream(), statusResponseCode);

                    Gson gson = new Gson();
                    HttpResObject resObject = gson.fromJson(res, HttpResObject.class);

                    // pokud se stavID == 3, ziskam token
                    if (resObject.stavID == 3) {
                        new Thread(tokenCallTask).start();
                    }
                }
                this.run();
            } catch (IOException e) {
                System.out.println(e.getMessage());
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    };

    Runnable tokenCallTask = new Runnable() {
        @Override
        public void run() {
            HttpsURLConnection connection = null;

            try {
                // vytvoreni https spojeni
                URL apiCallUrl = new URL(niaTokenUrl.getText() + niaUrlParam1.getText());
                connection = (HttpsURLConnection) apiCallUrl.openConnection();
                connection.setRequestMethod("GET");
                connection.setRequestProperty("User-Agent", "Chrome");
                connection.setReadTimeout(5000);
                connection.setSSLSocketFactory(sslSocketFactory);

                // po provolani ziskam odpoved z API
                int statusResponseCode = connection.getResponseCode();

                // pokud se vrati chybovy kod, zaloguji error
                if (statusResponseCode > 299) {
                    logApiResponse("TOKEN", connection.getErrorStream(), statusResponseCode);
                } else {
                    // jinak zaloguji token
                    logApiResponse("TOKEN", connection.getInputStream(), statusResponseCode);
                    disableForm(false);
                }
            } catch (IOException e) {
                System.out.println(e.getMessage());
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    };

    public void onStopButtonClicked() {
        // enabluje prvky formulare pro editaci
        disableForm(false);
    }

    private SSLSocketFactory createSSLContext(String keyStorePath, String keystorePassword) {
        try {
            keyStore = KeyStore.getInstance("pkcs12");
            keyStore.load(new FileInputStream(keyStorePath), keystorePassword.toCharArray());

            KeyManagerFactory kmf = null;
            kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
            kmf.init(keyStore, keystorePassword.toCharArray());

            SSLContext ctx = null;
            ctx = SSLContext.getInstance("TLS");
            ctx.init(kmf.getKeyManagers(), null, null);
            return ctx.getSocketFactory();
        } catch (KeyStoreException | IOException | NoSuchAlgorithmException | CertificateException |
                UnrecoverableKeyException | KeyManagementException e) {
            logToTerminal("Certifikát: " + e.getMessage() + System.getProperty("line.separator"), "");
            disableForm(false);
            return null;
        }
    }

    private String logApiResponse(String type, InputStream inputStream, int statusResponseCode) throws IOException {
        BufferedReader iReader = new BufferedReader(new InputStreamReader(inputStream));

        String line;
        String resBody = "";
        while ((line = iReader.readLine()) != null) {
            resBody += line;
        }
        iReader.close();

        String finalResBody = resBody;
        Platform.runLater(() -> {
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
            LocalDateTime now = LocalDateTime.now();
            logToTerminal(dtf.format(now) + " - (" + type +") - ", "");
            logToTerminal(String.valueOf(statusResponseCode) + System.getProperty("line.separator"),
                    statusResponseCode > 299 ? "-fx-fill: #FF4500;-fx-font-weight:bold;" : "-fx-fill: #4F8A10;-fx-font-weight:bold;");
            logToTerminal("  " + finalResBody + System.getProperty("line.separator"), "");
            scrollPane.vvalueProperty().bind(txa.heightProperty());
        });
        return resBody;
    }

    private void logToTerminal(String message, String style) {
        Text t = new Text();
        t.setText(message);
        if (!style.isEmpty()) {
            t.setStyle(style);
        }
        txa.getChildren().add(t);
    }

    private void disableForm(boolean disable) {
        isRunning = disable;
        startButton.setDisable(disable);
        stopButton.setDisable(!disable);
        niaUrlParam1.setDisable(disable);
        niaUrlParam2.setDisable(disable);
        password.setDisable(disable);
        certPath.setDisable(disable);
        certButton.setDisable(disable);
    }
}

class HttpResObject {
    public String popisChyby;
    public int kodChyby;
    public int stavID;
    public String token;
}